#!/bin/sh
#*----------------------------------------------------------------------------------------------------------
#* Maintenance routine
#*----------------------------------------------------------------------------------------------------------
cd /home/pi/Downloads/ngrok-stable-linux-arm
cat /var/log/syslog | grep "setngrok.py: T(" > $(pwd)/tucSPA/logs/tucSPA_telemetry_$(date +"%FT%H%M").log 2>&1  | logger -i -t "tucSPA.TLM"

#*--- Now delete all files older than 7 days
#find $(pwd)/tucSPA/logs -type f -mtime +7 -delete
#find $(pwd)/tucSPA/cam -type f -mtime +7 -delete

./cleanUp.sh
./rclone.sync
echo "Telemetry Log cycling and backup" 2>&1  | logger -i -t "tucSPA.TLM"
