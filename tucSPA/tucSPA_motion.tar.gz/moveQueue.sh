#!/bin/sh
cd /home/pi/Downloads/ngrok-stable-linux-arm

echo "User $(whoami) File ($1) Event($2)"  2>&1 | logger -i -t "moveQueue"
FILE=$(echo  $1 | cut -f 5 -d \/)
#echo "Motion filename ($FILE)" 2>&1 | logger -i -t "moveQueue"

#*------ Transfer to OneDrive folder
#SOURCE="/var/lib/motion"
#TARGET="onedrive:tucSPA/motion"
#rclone sync --config=/var/lib/motion/rclone.conf -v $SOURCE $TARGET 2>&1 | logger -i -t "moveQueue"
./rclone.motion

#*------ Upload to qsl.net site
HOST="ftp.qsl.net"
USERNAME="lu7did"
PASSWORD="cbn08sh7"
DIR="tucSPA/images"
echo "upload  ($1) to $HOST/$DIR using id($USERNAME)" 2>&1  | logger -i -t "moveQueue"
ftp-upload -h $HOST  -u $USERNAME --password $PASSWORD -d $DIR $1 2>&1 | logger -i -t "moveQueue"


DELIM=$(echo $FILE  | cut  -d . -f 2)
JPG="jpg"
MP4="mp4"
TO="pedro.colla@gmail.com"
#if [ "$DELIM" = "$JPG" ];
#then
#   echo "Delimiter jpg found photo" 2>&1 | logger -i -t "moveQueue"
#   echo "send mail URL to $FILE" 2>&1 | logger -i -t "moveQueue"
#   python sendmail.py pedro.colla@gmail.com pepe pedro.colla@gmail.com $FILE
#   exit 0
#fi

if [ "$DELIM" =  "$MP4" ];
then
   echo "Motion detected sent URL for $FILE to $TO" 2>&1 | logger -i -t "moveQueue"
   python sendmail.py $TO $FILE
   exit 0
fi
