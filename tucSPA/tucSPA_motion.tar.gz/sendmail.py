#!/usr/bin/python
import smtplib
import sys
import os
import syslog
import subprocess
for i, arg in enumerate(sys.argv):
    print("argument received["+str(i)+"] ->"+arg)
userid="pedro.colla@gmail.com"
password='vgoj oifr gdpe lnzb'
userTo=sys.argv[1]
message=sys.argv[2]
conn =smtplib.SMTP('smtp.gmail.com',587)
type(conn)
conn.ehlo()
conn.starttls()
conn.login(userid,password)
conn.sendmail(userTo,userTo,'Alerta de movimiento.\n\n@tucSPA\n'+'http://www.qsl.net/lu7did/tucSPA/images/'+message)
conn.quit()

