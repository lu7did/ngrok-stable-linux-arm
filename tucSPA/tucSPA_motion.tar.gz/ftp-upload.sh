#!/bin/sh
HOST="ftp.qsl.net"
USERNAME="lu7did"
PASSWORD="cbn08sh7"
DIR="tucSPA"
echo "upload  ($1) to $HOST/$DIR using id($USERNAME)"
ftp-upload -h $HOST  -u $USERNAME --password $PASSWORD -d $DIR $1
