#!/bin/sh

ls -l | grep '^[^d]' | awk '{print $9}' | xargs tar czvf tucSPA_motion.tar.gz
