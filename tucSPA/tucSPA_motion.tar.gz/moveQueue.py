#!/usr/python
# moveQueue.py
import sys
import syslog
import os
import subprocess
#*-----------------------------------------------------------------------------$
#* putLog
#*-----------------------------------------------------------------------------$
def putLog(m,printFlag):
    print m
    if printFlag:
       syslog.syslog(m)


if __name__ == "__main__":
    #print(f"Arguments count: {len(sys.argv)}")
    for i, arg in enumerate(sys.argv):
        putLog("argument received["+str(i)+"] ->"+arg,False)
        #print(f"Argument {i:>6}: {arg}")
fileName=sys.argv[1]
bashCommand = "cp "+fileName+" /home/pi/webcam/capture"
putLog("Bash "+bashCommand,True)
p=os.system(bashCommand)
putLog("File("+fileName+") moved to queue",True);
