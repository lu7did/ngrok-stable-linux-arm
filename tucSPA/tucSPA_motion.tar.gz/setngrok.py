#!/usr/bin/python
import subprocess
import sys
import psutil
import time
import os
from datetime import date
import datetime
import syslog
#*-------------------------------------------------------------------------------------
#* putLog
#*-------------------------------------------------------------------------------------
def putLog(m,printFlag):
    print m
    if printFlag:
       syslog.syslog(m)
#*-------------------------------------------------------------------------------------
#* Execute a process and return result with optional logging
#*-------------------------------------------------------------------------------------
def execProc(procName,printFlag):
   p = subprocess.Popen(procName, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
   t = p.stdout.read()
   putLog(t,printFlag);
#*-------------------------------------------------------------------------------------
#* Verify if process is running
#*-------------------------------------------------------------------------------------
def checkIfProcessRunning(processName):
    '''
    Check if there is any running process that contains the given name processName.
    '''
    #Iterate over the all the running process
    for proc in psutil.process_iter():
        try:
            # Check if process name contains the given name string.
            if processName.lower() in proc.name().lower():
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False;

#*-----------------------------------------------------------------------------------------------------
#* Program initialization
#*-----------------------------------------------------------------------------------------------------
flagFirst=True
today = date.today()
#*-----------------------------------------------------------------------------------------------------
#* Check if the process is already running, if not launch
#* If the process is running collect telemetry about the environment before ending
#*-----------------------------------------------------------------------------------------------------
if not checkIfProcessRunning('ngrok'):
   putLog("Start processing",True);
   os.chdir("/home/pi/Downloads/ngrok-stable-linux-arm")
   putLog("Current directory is "+os.getcwd(),True)
else:
   execProc("/home/pi/Downloads/ngrok-stable-linux-arm/setTelemetry.sh",True)
   sys.exit()

#*-----------------------------------------------------------------------------------------------------
#* Launch ngrok process
#*-----------------------------------------------------------------------------------------------------
process = subprocess.Popen(
    ["./ngrok","tcp","5900","-log=stdout"], stdout=subprocess.PIPE, stderr=subprocess.PIPE
)

#*-----------------------------------------------------------------------------------------------------
#* Process token detection just once
#*-----------------------------------------------------------------------------------------------------
for line in iter(process.stdout.readline,''):
   print line.rstrip()
   p=line.rstrip().find("url=");
   if p>0 and flagFirst:
      url=line.rstrip()[p+10:]
      now = datetime.datetime.now()

      putLog("ngrok new URL="+url,True)
      token_file = open("/home/pi/Downloads/ngrok-stable-linux-arm/tucSPA/tucSPA_url.txt", "w")
      str= "tucSPA ngrok access URL generated\r\n"+now.strftime("%Y-%m-%d %H:%M:%S")+" URL tcp://"+url+"\r\n"
      n = token_file.write(str)
      token_file.close()

      execProc("/home/pi/Downloads/ngrok-stable-linux-arm/rclone.sync",False)
      putLog("tucSPA access URL("+url+") updated at OneDrive",True)
      flagFirst=False
