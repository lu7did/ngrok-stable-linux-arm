#!/usr/bin/python
#*---------------------------------------------------------------
#* sendmail
#* send a mail message
#*---------------------------------------------------------------
import smtplib
import sys
import os
import syslog
import subprocess
from subprocess import PIPE,Popen

#*-------------------------------------------------------------------------------------
#* getToken from sitedata JSON
#*-------------------------------------------------------------------------------------
def getToken(token):
  t = Popen(['python', 'getJason.py','sitedata.json',token],stdout=PIPE)
  return t.communicate()[0].replace("\n", "")

#*--- define specific mail sender credentials

userid=getToken("mail")
password=getToken("token")
site=getToken("site")

#*--- define mail receiver and message

userTo=sys.argv[1]
message=sys.argv[2]

#*--- send mail

conn =smtplib.SMTP('smtp.gmail.com',587)
type(conn)
conn.ehlo()
conn.starttls()
conn.login(userid,password)
conn.sendmail(userTo,userTo,'Alerta de movimiento.\n\n@'+site+'\n'+'http://www.qsl.net/lu7did/'+site+'/images/'+message)
conn.quit()

