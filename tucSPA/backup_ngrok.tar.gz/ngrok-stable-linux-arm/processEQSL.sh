#!/bin/sh
#*-----------------------------------------------------------------------*
#* processEQSL.sh                                                        *
#* Process all ADIF files (.ADI) on a given directory and upload them    *
#* into eQSL.cc, this process is stand alone to process imports          *
#* to process individual logs use processADIF.sh instead                 *
#*-----------------------------------------------------------------------*
#*---- Retrieve execution environment
DIR=$1
CURR=$(pwd)
PWD=$(dirname $0)
chdir $PWD

#*--- Retrieve keys
TO=$(python getJason.py sitedata.json  mail)
SITE=$(python getJason.py sitedata.json site)
CALL=$(python getJason.py sitedata.json call)
NODE="$CALL @ $SITE"
MASTER=$CALL"_"$SITE"_MASTER.log"

#*--- Get directory to scan for .ADI files
if [ "$DIR" = "" ]; then
   DIR="."
fi

#*--- Extract files and process
FILES=$(ls $DIR/*.adi)
echo "Processing QSL to eQSL.com" 2>&1 | logger -i -t "eQSL.cc"
POST=$(echo "\n\rProcess ADIF files at node($NODE)\n\rdirectory($DIR)\n\r")

for F in $FILES
do
   while IFS= read -r line
   do
     M=$(echo $line | cut -d " " -f 1)
     if [ "$M" != "ADI" ]; then
        H=$(echo "$line" | cut -d ":" -f 1 | tr -d '\r' | tr -d '\n')
        if [ "$H" = "<call" ]; then
           CALL=$(echo $line | cut -d "<" -f 2 | cut -d ">" -f 2)
           QRZpost="python /home/pi/Downloads/ngrok-stable-linux-arm/eqslpost.py INSERT '$line'"
           RESP=$($QRZpost)
           POST=$(echo "\n\r"$POST"\n\rQSO("$CALL")\n\rResponse("$RESP")\n\r")
           echo "$(date) processed QSO with ($CALL)\n\rResponse($RESP)\n\r" 2>&1 | logger -i -t "qrz.com"
           echo "$(date) processed QSO with ($CALL)\n\rResponse($RESP)\n\r" 
        else
           echo "$(date) rejected QSO with ($CALL) record ignored\n\r" 2>&1 | logger -i -t "qrz.com"
        fi
     fi
   done < "$F"
done
cd $CURR
