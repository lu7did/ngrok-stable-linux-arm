
#!/bin/sh
#*-----------------------------------------------------------------------*
#* processQSL                                                            *
#* Process all ADIF files (.ADI) on a given directory and upload them    *
#* into different supported QSL platforms                                *
#*-----------------------------------------------------------------------*
#*---- Retrieve execution environment
clear
CURR=$(pwd)
PWD=$(dirname $0)
ADI=$PWD/ADIF
LCK=$PWD/ADIF/processQSL.lck
echo "Current($CURR) PWD($PWD) ADIF($ADI)\n"
cd $PWD

export DISPLAY=:0.0
NGROK="/home/pi/Downloads/ngrok*"
WSJTZ="/home/pi/.local/share/WSJT-X"
ROOT="/root/.local/share/WSJT-X"

#*--- Retrieve site specific keys and parameters
TO=$(python getJason.py sitedata.json  mail)
SITE=$(python getJason.py sitedata.json site)
CALL=$(python getJason.py sitedata.json call)
PASS=$(python getJason.py sitedata.json lotw.pass)

#*--- Retrieve site data keys for ClubLog

CODING="Content-Type: application/x-www-form-urlencoded"
CLUBLOG_ID=$(python getJason.py sitedata.json clublog.id)
CLUBLOG_PASS=$(python getJason.py sitedata.json clublog.pass)
CLUBLOG_API=$(python getJason.py sitedata.json clublog.api)
CLUBLOG_URL=$(python getJason.py sitedata.json clublog.url)


#*--- Processing environment

NODE="$CALL @ $SITE"
MASTER=$CALL"_"$SITE"_MASTER.log"
tmpFile="tmpFile"
QFILES=0

#*--- Inet reference
INET="http://google.com"
QNET=0
INETFILE="inetcheck"

#*----- Check for re-entrancy
if test -f "$LCK"; then
   HOST=$(hostname)
   POST=$(echo "Program processQSL re-entrancy detected ($HOST), check lock exit")
   echo "Error message($POST)"
   python /home/pi/Downloads/ngrok-stable-linux-arm/sendmail_qrz.py $TO $CALL $POST 2>&1 | logger -i -t "processQSL"
   exit 0
fi

#*---- Lock in place to prevent re-entrancy (however, if the script fails will prevent further exectution until cleared)
touch $LCK

#*--- Check Inet availability
wget -q --spider $INET
if [ $? -eq 0 ]; then
   QNET=1
   INETMSG=$(echo "Internet connectivity site ($SITE) found ok $(date) ")
   echo $INETMSG
else
   INETMSG=$(echo "Internet connection site($SITE) failed at $(date)")
   echo $INETMSG 2>&1  | tee -a $INETFILE
   cd $CURR
   rm -r $LCK >&1 > /dev/null
   exit 1
fi


#*--- Remove previous temporary file
if test -f $tmpFile; then
rm -r $tmpFile 2>&1 > /dev/null 
fi

#*--- Create temporary message file
touch $tmpFile 2>&1 > /dev/null


echo "Processing activity Site($SITE) Call($CALL) Node($NODE) Directory($ADI)\n\r" 2>&1 | tee -a  $tmpFile
echo $INETMSG 2>&1 | tee -a $tmpFile

#*--  Verify if previous Internet issues happened, if so include a message in the mail (and force a mail)
if test -f "$INETFILE"; then

    echo "\r\n" 2>&1 | tee -a $tmpFile
    echo "*************************************************\r\n" 2>&1 | tee -a $tmpFile
    echo "---               WARNING                     ---\r\n" 2>&1 | tee -a $tmpFile
    echo "--- Previous Internet unavailability detected ---\r\n" 2>&1 | tee -a $tmpFile
    echo "*************************************************\r\n" 2>&1 | tee -a $tmpFile
    cat $INETFILE >> $tmpFile
    echo "\r\n*************************************************\r\n" 2>&1 | tee -a $tmpFile

    QFILES=$((QFILES+1))
    rm -r $INETFILE 2>&1 > /dev/null 

fi


#*--- Copy ADIF from WSJT-X activity and log directory

if test ! -f $WSJTZ/wsjtx_log.adi; then
   echo "File ($WSJTZ/wsjtx_log.adi) not found, process terminated" 2>&1 | tee -a $tmpFile
   if [ "$QFILES" -gt "0" ]; then
      echo "\r\nSending mail to ($TO)" 2>&1 | tee -a $tmpFile
      POST=$(cat $tmpFile)
      python /home/pi/Downloads/ngrok-stable-linux-arm/sendmail_qrz.py $TO $CALL "No ADIF @ $SITE" $POST 2>&1 | logger -i -t "processQSL"
   else
      echo "No pending activity"
   fi
   rm -r $LCK >&1 > /dev/null
   exit 0  
fi

#*--- Process the WSJT-X.adi file recovering the new data
 
if test ! -f $ADI/wsjtx.old; then
   echo "File ($ADI/wsjtx.old) not found creating it" 2>&1 | tee -a $tmpFile
   touch $ADI/wsjtx.old 2>&1 > /dev/null 
fi

#*--- Store the last adif file into the old to prevent further processing
if test -f $WSJTZ/wsjtx_log.adi; then
   cp $WSJTZ/wsjtx_log.adi $ADI/wsjtx.new
   echo "\r\nCopying ($WSJTZ/wsjtx_log.adi) into ($ADI/wsjtx.new)" 2>&1 | tee -a $tmpFile
fi

#if test -f $ROOT/wsjtx_log.adi; then
#   sudo cat $ROOT/wsjtx_log.adi >> $ADI/wsjtx.new 
#   echo "\r\nAppending ($ROOT/wsjtx_log.adi) into ($ADI/wsjtx.new)" 2>&1 | tee -a $tmpFile
#fi

#*--- Detect differences between current ADIF and previous one, cut the difference only
python3 $PWD/compareADIF.py $ADI/wsjtx.new $ADI/wsjtx.old > $ADI/wsjtx.adi

#*--- Rotate the reference
cat $ADI/wsjtx.adi > $ADI/wsjtx.adi.bup
cp $ADI/wsjtx.new $ADI/wsjtx.old 2>&1 > /dev/null 

#*--- Prevent execution if the ADIF file is empty

SADI=$(stat -c %s "$ADI/wsjtx.adi")
if [ "$SADI" -eq "0" ]; then
   echo "File ($WSJTZ/wsjtx.adi) empty, process terminated" 2>&1 | tee -a $tmpFile
   if [ "$QFILES" -gt "0" ]; then
      echo "\r\nSending mail to ($TO)" 2>&1 | tee -a $tmpFile
      POST=$(cat $tmpFile)
      python /home/pi/Downloads/ngrok-stable-linux-arm/sendmail_qrz.py $TO $CALL "No ADIF activity @ $SITE" $POST 2>&1 | logger -i -t "processQSL"
   else
      echo "No pending activity"
   fi
   rm -r $LCK >&1 > /dev/null
   exit 0  
fi

#*--- Extract files and process, would process the file from WSJT-X plus any other placed in the directory with .adi extension

FILES=$(ls $ADI/*.adi)

for f in $FILES
do
  echo "\r\nProcessing file ($f)\r\n" 2>&1 | tee -a $tmpFile
#*-----------------(Process LoTW using TQSL)-----------------------------------
#* Certificate of trust from ARRL must be availble for the CALL used
#*-----------------------------------------------------------------------------
  echo "\r\nLoTW Upload file($f) Result\n\r" 2>&1 | tee -a $tmpFile
  LINE=$(tqsl -c $CALL -d -u -q -a all -x -d -p $PASS  $f 2>&1)
  echo "\r\n$LINE\n\r" 2>&1 | tee -a  $tmpFile

#*-----------------(Process Log de Argentina (LdA)-----------------------------
  echo "\r\nLdA Upload file($f) Result\n\r" 2>&1 | tee -a $tmpFile
  python3.7 $NGROK/postLdA.py $f 2>&1 | tee -a $tmpFile 

#*-----------------(Process QRZ.com)-------------------------------------------
  echo "\r\nQRZ.com Upload file($f) Result\n\r" 2>&1 | tee -a $tmpFile
  python3.7 $NGROK/postQRZ.py $f 2>&1 | tee -a $tmpFile 

#*-----------------(Process eQSL.cc)-------------------------------------------
  echo "\r\neQSL.cc Upload file($f) Result\n\r" 2>&1 | tee -a $tmpFile
  python3.7 $NGROK/postEQSL.py $f 2>&1 | tee -a $tmpFile 

#*-----------------[Process ClubLog]-------------------------------------------
  echo "\r\nClubLog Upload file($f) Result\n\r" 2>&1 | tee -a $tmpFile
  $NGROK/postClubLog.sh $f 2>&1 | tee -a $tmpFile 
  echo " " 2>&1 | tee -a $tmpFile 
  echo " " 2>&1 | tee -a $tmpFile 

#*------------------(Archive ADI files)
  echo "\r\nStoring $f at $ADI/$MASTER" 2>&1 | tee -a $tmpFile

  cat $f 2>&1 >> $ADI/$MASTER 
  rm -r $f 2>&1 > /dev/null
  QFILES=$((QFILES+1))
done

if [ "$QFILES" -gt "0" ]; then

#*-----------------(Send mail with results)------------------------------------
   echo "\r\nSending mail to ($TO)" 2>&1 | tee -a $tmpFile
   POST=$(cat $tmpFile)
   python /home/pi/Downloads/ngrok-stable-linux-arm/sendmail_qrz.py $TO $CALL "ADIF Upload @ $SITE" "$POST" 2>&1 | logger -i -t "processQSL"
   cat $tmpFile 2>&1 | logger -i -t "processQSL"

else
   echo "\r\nNo activity files found" 2>&1 | tee -a $tmpFile
fi

#*----- final clean up ante termination

rm -r $tmpFile 2>&1 > /dev/null
rm -r $ADI/wsjtx.new 2>&1 > /dev/null
rm -r $LCK
cd $CURR
#*-----------------------------------------------[End of Script]-----------------------------------------------------
